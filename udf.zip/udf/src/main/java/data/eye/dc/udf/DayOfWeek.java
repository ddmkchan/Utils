package data.eye.dc.udf;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;


@Description(name = "DayOfCalendar", value = "_FUNC_ (string dt) - return the Calendar of dt.")  
public class DayOfWeek extends UDF {
	
	Calendar c = Calendar.getInstance();
	
    public Integer evaluate(String _date) {
    	
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		java.util.Date dt;
		try {
			dt = sdf.parse(_date);
			c.setTime(dt);
			return c.get(Calendar.DAY_OF_WEEK);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return -1;
    }
    

}