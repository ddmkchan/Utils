package data.eye.dc.udf;

import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;


@Description(name = "a special regex function", value = "_FUNC_ (string text) - return city of text")  
public class SpeRegex extends UDF {
	
	
    public String evaluate(String str) {
    	
    	String city = "未知";
  	  	Pattern p = Pattern.compile("([\u4e00-\u9fa5]*?)市");
  	  	Matcher m = p.matcher(str);
  	  	if(m.find()) {
  	  		city = m.group(1)+"市";
  	  		return city;
  	  	}
  	  	return city;
    }
    

}