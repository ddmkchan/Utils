package data.eye.dc.udf;

import java.util.ArrayList;
import java.util.List;

import org.ansj.domain.Term;
import org.ansj.library.UserDefineLibrary;
import org.ansj.splitWord.analysis.BaseAnalysis;
import org.ansj.splitWord.analysis.ToAnalysis;

/**
 * Hello world!
 *
 */
public class App 
{
    public static int evaluate(String input, int pos, boolean isFloat) {
    	int out=0;
        try {
        	String[] segments = input.split(",");
        	for (String s:segments) {
        		String[] ret = s.split(":");
        		if (isFloat) {
            		out += Float.parseFloat(ret[pos]);
        		} else {
            		out += Integer.parseInt(ret[pos]);
        		}

        	}
        } catch (Exception e) {
            // Can't happen
        	e.printStackTrace();
        }
    	return out;
    }
    
    public static void main( String[] args )
    {
//    	System.out.println(evaluate("1438272000:2:30.0", 2, true));
//    	ArrayList<Integer> mylist = new ArrayList<Integer>();
//    	ArrayList<Integer> mylist2 = new ArrayList<Integer>();
//    	mylist2.add(2);
//    	mylist.addAll(mylist2);
//    	mylist.addAll(mylist2);
//    	System.out.println(mylist);
//        UserDefineLibrary.insertWord("飞利信", "", 1000);
        List<Term> terms = ToAnalysis.parse("我猴赛利觉得飞利信是一个不错的系统!我是王婆!");
        System.out.println("增加新词例子:" + terms);
        List<String> out = new ArrayList<String>();
        boolean isPos = true;
        for (Term t:terms) {
        	if (isPos) {
        		if (t.toString().indexOf("/")!=-1) {
                	out.add(t.toString().split("/")[0]);
        		}
        	} else {
            	out.add(t.toString());
        	}

        }
        System.out.println(out);
    }
}
