package data.eye.dc.udf;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;


@Description(name = "split_sum",  
value = "_FUNC_(string, int, isFloat) - return the sum of object", extended = "Example:\n split '1437753600:4:3940,1437840000:11:3345' and sum 3940+3345")  
public class SplitAndSum extends UDF {

    public int evaluate(String input, int pos, boolean isFloat) {
    	int out=0;
        try {
        	String[] segments = input.split(",");
        	for (String s:segments) {
        		String[] ret = s.split(":");
        		if (isFloat) {
            		out += Float.parseFloat(ret[pos]);
        		} else {
            		out += Integer.parseInt(ret[pos]);
        		}

        	}
        } catch (Exception e) {
            // Can't happen
        	e.printStackTrace();
        }
    	return out;
    }
}