package data.eye.dc.udf;

import java.io.IOException;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;


@Description(name = "IsSubString",  
value = "_FUNC_(String s1, String s2) - return true if a string contain a specified substring. \n")  
public class IsSubString extends UDF {

    public boolean evaluate(String s1, String s2) {
    	if (s1.indexOf(s2) != -1) {
    		return true;
    	}
    	return false;
    }
	public static void main(String[] args) throws IOException {
		IsSubString a = new IsSubString();
		System.out.println(a.evaluate("微信v2","微信"));
    }
}