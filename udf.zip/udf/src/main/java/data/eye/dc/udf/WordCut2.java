package data.eye.dc.udf;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.ansj.domain.Term;
import org.ansj.library.UserDefineLibrary;
import org.ansj.splitWord.analysis.ToAnalysis;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;


@Description(name = "word cut",  
value = "_FUNC_(string str, boolean isPos) - return the splited terms for the input sentence."+"\n return Pos if isPos is true")  
public class WordCut2 extends UDF {
	
    public List<String> evaluate(String sentence, boolean isPos) throws IOException {
    	
    	List<String> out = new ArrayList<String>();
    	InputStream f = Object.class.getResourceAsStream("/default.dic");
        BufferedReader br=new BufferedReader(new InputStreamReader(f));   
        String s="";   
        while((s=br.readLine())!=null) {
        	UserDefineLibrary.insertWord(s, "n", 1000);
        }
        List<Term> terms = ToAnalysis.parse(sentence);
    	if (isPos) {
            for (Term t:terms) {
            	out.add(t.toString());
            }
    	} else {
            for (Term t:terms) {
            	out.add(t.getName());
            }
    	}
    	return out;
    }
	public static void main(String[] args) throws IOException {
		WordCut2 a = new WordCut2();
		System.out.println(a.evaluate("我们都是飞利信中国人", false));
		System.out.println(a.evaluate("我们都是飞利信中国人", true));
    }
}