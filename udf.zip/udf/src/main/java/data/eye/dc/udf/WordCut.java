package data.eye.dc.udf;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.ansj.domain.Term;
import org.ansj.splitWord.analysis.ToAnalysis;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;


@Description(name = "Segmenter", value = "_FUNC_ (string sentence) - return the splited terms for the input sentence.")  
public class WordCut extends UDF {
	
    public List<String> evaluate(String sentence) throws IOException {
    	List<String> out = new ArrayList<String>();
        List<Term> terms = ToAnalysis.parse(sentence);
        for (Term t:terms) {
        	out.add(t.getName());
        }
    	return out;
    }
    
	public static void main(String[] args) throws IOException {
		WordCut a = new WordCut();
		System.out.println(a.evaluate("我们都是飞利信中国人"));
		System.out.println(a.evaluate("(ansj中文分词)在这12栋A楼B栋"));
    }
}